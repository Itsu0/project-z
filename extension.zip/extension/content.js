// ── Nexus PTT — Content Script ───────────────────────────────────────────────
// Działa wewnątrz karty Nexus. Przekazuje sygnały PTT z background do strony.

// Odbierz wiadomość od background service workera
chrome.runtime.onMessage.addListener((message) => {
  if (message.type !== 'NEXUS_PTT') return;

  // Wyślij zdarzenie do strony (VoiceContext nasłuchuje tego eventu)
  window.dispatchEvent(new CustomEvent('nexus-ext-ptt', {
    detail: { active: message.active }
  }));
});

// Poinformuj stronę że rozszerzenie jest zainstalowane
window.dispatchEvent(new CustomEvent('nexus-ext-ready', {
  detail: { version: '1.0.0' }
}));

// Ping co 5 sekund żeby strona wiedziała że rozszerzenie nadal działa
setInterval(() => {
  window.dispatchEvent(new CustomEvent('nexus-ext-ping'));
}, 5000);
